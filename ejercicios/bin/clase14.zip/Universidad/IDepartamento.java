package Universidad;

public interface IDepartamento {
    String getNombre();
    void asignarEstudiante(IEstudiante estudiante);
    void mostrarInformacion();
}
