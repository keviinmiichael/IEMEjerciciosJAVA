package Universidad;

public interface IAsignatura {
    String getNombre();
    void asignarProfesor(IProfesor profesor);
    void mostrarInformacion();
}
