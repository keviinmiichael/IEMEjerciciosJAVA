package Universidad;

public interface ICurso {
    String getNombre();
    void matricularEstudiante(IEstudiante estudiante);
    void mostrarInformacion();
}
