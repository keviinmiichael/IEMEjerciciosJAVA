package Universidad;

public interface IProfesor extends IPersona {
    void asignarAsignatura(IAsignatura asignatura);
    void mostrarAsignaturas();
}
