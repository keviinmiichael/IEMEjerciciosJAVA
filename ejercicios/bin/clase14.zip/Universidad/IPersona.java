package Universidad;

public interface IPersona {
    String getNombre();
    String getFechaNacimiento();
    String getGenero();
    String getDireccion();
    void mostrarInformacionPersonal();
}
