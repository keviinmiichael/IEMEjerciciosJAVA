package joyeria;

public interface JoyaConPerlas extends Joya {
    void agregarPerlas(int cantidad);
}
