package joyeria;

public interface Joya {
    void obtenerInformacion();
    double calcularPrecio();
}