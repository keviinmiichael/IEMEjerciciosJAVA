package joyeria;

public interface JoyaConDiamantes extends Joya {
    void agregarDiamantes(int cantidad);
}
