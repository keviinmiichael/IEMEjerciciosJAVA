package jugueteria;

public interface Juguete {
    void obtenerInformacion();
    double calcularPrecio();
}
